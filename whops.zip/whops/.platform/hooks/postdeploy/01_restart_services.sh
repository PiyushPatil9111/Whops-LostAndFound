#!/bin/bash
sudo systemctl restart eb-app.service
sudo systemctl restart nginx.service